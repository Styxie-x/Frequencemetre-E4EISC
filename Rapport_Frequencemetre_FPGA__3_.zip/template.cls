\NeedsTeXFormat{LaTeX2e}
\ProvidesClass{template}[2026/02/10 Template Styxie]
\LoadClass[11pt,a4paper]{article}

% Encodage et langue
\RequirePackage[utf8]{inputenc}
\RequirePackage[T1]{fontenc}
\RequirePackage[french]{babel}
\RequirePackage{lmodern}

% Mise en page
\RequirePackage{geometry}
\geometry{top=2.5cm, bottom=2.5cm, left=2.5cm, right=2.5cm, headheight=15pt}

% Mathematiques et unites
\RequirePackage{amsmath,amssymb,amsfonts}
\RequirePackage{siunitx}
\sisetup{locale = FR, detect-all}

% Figures et tableaux
\RequirePackage{graphicx}
\RequirePackage{booktabs}
\RequirePackage{array}
\RequirePackage{subcaption}
\RequirePackage{float}

% Legendes (nom + reference) TOUJOURS sous les tableaux ET sous les figures.
\captionsetup{position=bottom, labelfont=bf, font=small}
\captionsetup[table]{position=bottom, skip=6pt}
\captionsetup[figure]{position=bottom}

% Couleurs de la charte ESIEE
\RequirePackage[table,xcdraw]{xcolor}
\definecolor{esieeBlue}{RGB}{0, 75, 135}
\definecolor{techGray}{RGB}{100, 110, 120}
\definecolor{codeBg}{RGB}{245, 247, 250}
\definecolor{alertRed}{RGB}{180, 0, 0}

% Liens hypertextes
\RequirePackage{hyperref}
\hypersetup{
    colorlinks=true,
    linkcolor=esieeBlue,
    citecolor=esieeBlue,
    urlcolor=esieeBlue
}

% En-tetes et pieds de page
\RequirePackage{fancyhdr}
\pagestyle{fancy}
\fancyhf{}
\fancyhead[L]{\small\color{techGray}\nouppercase{\leftmark}}
\fancyhead[R]{\small\color{techGray}ESIEE Paris - Projet Fr\'equencem\`etre FPGA}
\fancyfoot[L]{%
  \raisebox{-0.2\height}{\includegraphics[height=0.55cm]{logo_esiee}}\hspace{0.3cm}%
  \raisebox{-0.2\height}{\includegraphics[height=0.55cm]{logo_ugeiffel}}%
}
\fancyfoot[C]{\small\color{techGray}\thepage}
\fancyfoot[R]{\small\bfseries\color{esieeBlue}Fr\'equencem\`etre FPGA}
\renewcommand{\headrulewidth}{0.4pt}
\renewcommand{\footrulewidth}{0.4pt}
\setlength{\footskip}{1.4cm}

% Blocs de code
\RequirePackage{listings}
\lstset{
    basicstyle=\small\ttfamily,
    backgroundcolor=\color{codeBg},
    frame=single,
    rulecolor=\color{techGray!30},
    keywordstyle=\color{esieeBlue}\bfseries,
    commentstyle=\color{techGray}\itshape,
    breaklines=true,
    captionpos=b,
    tabsize=2
}

% Le resume de la premiere page s'intitule "Resume" (et non "Abstract")
\addto\captionsfrench{\renewcommand{\abstractname}{R\'esum\'e}}

% Macro pour les elements a completer
\newcommand{\todo}[1]{\textcolor{alertRed}{\textbf{[A COMPL\'ETER : #1]}}}